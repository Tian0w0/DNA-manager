
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/*
Dati n elementi distinti, si dicono permutazioni, P(n), i gruppi che si possono formare in modo che:
ogni gruppo contenga tutti gli n elementi
ogni gruppo differisca dagli altri solo per l'ordine degli elementi*/




int checkLunghezza(char* name)
{
  int i = 0;
  while(*(name+i) != '\0')
  {
   i++;
  } 
return i;
}//serve per contare la quantita della string

char* attaccotxt(char* name, int l)
{
  char txt[4] = {'.','t','x','t'};
  for(int i = 0; i < 4; i++)
  {
    *(name + l + i) = txt[i];
  }
  return name;
}




typedef struct {
  char* array1;
  int l;
}string;

void elimina(string *row)
{
  char *tmp = row->array1;
  row->array1 = NULL;
  free(tmp);
}

int contaS(string*row)
{
  int j = 0;
  for(int i = 0; i<262144; i++)
  {
    if((row+i)->array1 != NULL)
    {
      j++;
    }
  }
  return j;
}

void riempi(string*row,FILE*file)
{
  for(int i = 0; i < 262144; i++)
  {
    if((row+i)->array1 != NULL)
    {
      fprintf(file,"%s\n",(row+i)->array1);
    } 
  }

}

void stampa(string *row)
{
  for(int i = 0; i < 262144; i++)
  {
    if((row+i)->array1 != NULL)
    {
      printf("%s\n",(row+i)->array1);
    } 
  }
}

int checkAdiancenti(string *row, int el, int num, int count, int right, FILE*file, int savedfile, int stamp)
{
  
  if(savedfile == 1)
  {
    fprintf(file, "The eliminated elements by the filter 1 :\n");
  }
  if(stamp == 1)
  {
    printf("\nThe following are the eliminated elements\n");
  }
  for(int i = 0; i < 262144; i++)
  {
    if((row+i)->array1 != NULL)
    {
      count = 1;
      right = 0;
      for(int j = 0; j < 17; j++)//17 per controllare la penultima posizione a l'ultima
      {   
        
        if((row+i)->array1[j] == (row+i)->array1[j+1])
        {
          count++;
          if(count >= num)
          {
           right = 1;
         }
      }
      else
      {
        count = 1;
      }
    }
    if(right == 1)
    {
      
      el++;
      
      if(savedfile == 1)
      {
        fprintf(file,"%s\n",(row+i)->array1);
      }
      if(stamp == 1)
      {
        printf("%s\n",(row+i)->array1);
      }
      elimina(row+i);
    }
    }    
  }
  return el;
}

int checkContenuto(string *row, char c, int num, FILE* file, int savefile, int stamp)
{
  if(savefile == 1)
  {
    fprintf(file, "\nThe elements eliminated by filter 4 : \n");
  }
  if(stamp == 1)
  {
    printf("\nThe elements eliminated by filter 4 : \n");
  }
  int el = 0;
  for(int i = 0; i < 262144; i++)
  {
    if((row+i)->array1 != NULL)
    {
      int count = 0;
      for(int j = 0; j<18; j++)
      {
        if((row+i)->array1[j] == c)
        {
          count++;
        }
      }
      if(count > num)
      {
        
        el++;
        if(savefile == 1)
        {
          fprintf(file, "%s\n",(row+i)->array1);
        }
        if(stamp == 1)
        {
          printf("%s\n",(row+i)->array1);
        }
        //printf(row+i)->array1;
        elimina(row+i); 
      } 

    }
      
  }
  return el;
}

void contenutoAGM(string *row, FILE*log, FILE*eliminated, int savefile, int stamp)
{
  char useonetime[255];
  int first = 0;
  int right = 0;
  int x;
  char c;
  //do
  //{
    do
    {
      if(first!=0)
      {
        printf("The number %d it's not valid, choose a number beetween 0 and 18\n", x);
      }
      else
      {
        printf("Insert the number of the content\n");
      }
    scanf("%s",useonetime);
    system("clear");
    x = atoi(useonetime);
    first++;
    }while(x<0 || x>18);
    first = 0;
    do
    {
      if(first!=0)
      {
        printf("The character %c it's not valid, choose a character beetween A and G\n", c);
      }
      else
      {
        printf("Insert the DNA data of the content, A/G\n");
      }      
      scanf("%s",useonetime);
      system("clear");
      c = useonetime[0];
      if(c == 'A' || c == 'G')
      {
        right = 1;
      }
      first++;
    }while(right != 1);
    
  //}while();
  int eliminati = checkContenuto(row, c, x,eliminated, savefile, stamp);
  fprintf(log,"%d are elements eliminated by the filter 4\n", eliminati);
  printf("%d elements are eliminated\n", eliminati);

}

int binary(string * row)
{
  int somma = 0;
  for(int i = 17; i >= 0; i--)
  {
    if(row->array1[i] == 'G')
    {
      somma += pow(2,i);
    } 
  }
  return somma;
}

int binarypiece(char *a, char*b, char*c)
{
  int at = 0;
  int bt = 0;
  int ct = 0;
  for(int i = 5; i>=0; i--)
  {
    if(a[i]=='A')
    {
      at+= pow(2,i);
    }
    if(b[i]=='A')
    {
      bt+= pow(2,i);
    }
    if(c[i]=='A')
    {
      ct+= pow(2,i);
    }
  }
  return at+bt+ct;
}
int binarypiece2(char *a, char*b)
{
  int at = 0;
  int bt = 0;
  for(int i = 8; i>=0; i--)
  {
    if(a[i]=='A')
    {
      at+= pow(2,i);
    }
    if(b[i]=='A')
    {
      bt+= pow(2,i);
    }

  }
  return at+bt;
}



int checkMirror(string * row, FILE*eliminated, int savefile, int stamp)
{
  if(savefile==1)
  {
    fprintf(eliminated,"\nThe elements deleted by filter 3, LEFT are the deleted one, RIGHT the deleted one\n");
  }
  if(stamp == 1)
  {
    printf("\nThe elements deleted by filter 3, LEFT are the deleted one, RIGHT the deleted one\n");
  }
  int el = 0;
  for(int i = 0; i < 262144; i++)
  {
    if((row+i)->array1 != NULL)
    { 
      int bi = binary(row+i);
      if((row+bi)->array1 != NULL)
      {
        //printf("\n%s,%s\n",(row+i)->array1,(row+bi)->array1);
        el++;
        if(savefile == 1)
        {
          fprintf(eliminated,"%s,%s\n",(row+i)->array1,(row+bi)->array1);

        }
        if(stamp == 1)
        {
          printf("%s,%s\n",(row+i)->array1,(row+bi)->array1);

        }
        elimina(row+bi);
      }    
    }
  }
  return el;
}

void mirrorM(string*row, FILE*file, FILE*eliminated, int savefile, int stamp)
{
  int eliminati = checkMirror(row, eliminated, savefile, stamp);
  fprintf(file,"%d are elements eliminated by the filter 3\n", eliminati);
  printf("%d elements are eliminated\n", eliminati);

}

int checkpalindromo(string * row, FILE*file, int savefile, int stamp)
{
  if(savefile == 1)
  {
    fprintf(file, "\nThese are the palindrome filter : \n");

  }
  if(stamp == 1)
  {
    printf("\nThese are the palindrome filter : \n");
  }
  int el = 0;
  for(int i = 0; i < 262144; i++)
  {   
    if((row+i)->array1 != NULL)
    {
      int right = 0;
      int k = 17;
      for(int j = 0; j < 9; j++, k--)//controllare la 1 con l'ultima
      {
        if((row+i)->array1[j] != (row+i)->array1[k])
        {
         right = 1;
        }
      }
      if(right == 0)
      {
        el++;
        if(savefile == 1)
        {
          fprintf(file, "%s\n",(row+i)->array1);
        }
        if(stamp == 1)
        {
          printf("%s\n",(row+i)->array1);
        }
        //printf("%s\n",(row+i)->array1);
        elimina(row+i);
      }
    } 
  }
  return el;
}
void palindromoM(string **row, FILE*log, FILE*eliminated, int savefile, int stamp)
{
  int eliminati = checkpalindromo(*row, eliminated, savefile, stamp);
  //stampa(*row);
  fprintf(log,"%d are elements eliminated by the filter 2\n", eliminati);
  printf("%d elements are eliminated\n", eliminati);

}
int thanosClean(string *row, int x, FILE*file, int save, int stamp)
{
  int el = 0;
  int limite = contaS(row) - 100;
  for(int i = 0; i < 262144 && el < limite; i++)
  {
    if((row+i)->array1 != NULL)
    {
      el++;
      if(save == 1)
      {
        fprintf(file, "%s\n", (row+i)->array1);
      }
      if(stamp == 1)
      {
        printf("%s\n", (row+i)->array1);
      }
      elimina(row+i);
    
    }
  }
  return el;

}
int thanos(string *row, int tha, FILE* file, int save, int stamp)
{
  if(save == 1)
  {
    fprintf(file, "The sequences that Thanos had deleted from the earth : \n");
  }
  if(stamp == 1)
  {
    printf("The sequences that Thanos had deleted from the earth : \n");
  }
  int ciao = 0;
  int el = 0;
  for(int i = 0; i < 262144; i++)
  {
    char*a = (char*)malloc(sizeof(char)*6);
    char*b = (char*)malloc(sizeof(char)*6);
    for(int j = 0; j < 9; j++)
    {
      a[j] = (row+i)->array1[j];
      b[j] = (row+i)->array1[j+9];
      //c[j] = (row+i)->array1[j+12];

    }
    int somma = binarypiece2(a,b);
    if(somma != tha)
    {
      
      el++;
      if(save == 1)
      {
        fprintf(file, "%s\n", (row+i)->array1);
      }
      if(stamp == 1)
      {
        printf("%s\n", (row+i)->array1);
      }
        elimina(row+i);
    }
    free(a);
    free(b);

    
  }
  printf("%d\n",contaS(row));
  if(contaS(row)>100)
  {
    el += thanosClean(row, tha, file, save, stamp);
  }
  //printf("%d",ciao);
  return el;
}

void thanosM(string **row, FILE*log, FILE*eliminated, int savefile, int stamp)
{
  char useonetime[2];
  int first = 0;
  int x = 0;
  do
    {
      if(first!=0)
      {
        printf("The number %d doesn't exist, choose a number to save the sequences beetween 0 and 2621\n", x);
      }
      else
      {
        getchar();
        printf("Thanos is going to destroying the sequences...\nPress ENTER to continue...\n");
        getchar();
        system("clear");
        printf("Only few of them will survive...\nPress ENTER to continue...\n");
        getchar();
        system("clear");
        printf("The only thing u can do now is to specify a number...\nPress ENTER to continue...\n");
        getchar();
        system("clear");
        printf("Choose it carefully from 0 to 1022!\nPress ENTER to continue...\n");
        getchar();
        system("clear");
        printf("So... What is your decision?\n");

      }
    scanf("%s",useonetime);
    system("clear");
    x = atoi(useonetime);
    first++;
    }while(x<0 || x>1022);

    int eliminati = thanos(*row, x, eliminated,savefile, stamp);
    fprintf(log,">> Thanos have eliminated %d sequences <<\n", eliminati);
    printf("%d elements are eliminated by Thanos\n", eliminati);

    

}

void adiacentiM(string** row, FILE*log, FILE*eliminated, int savefile, int stamp)
{
  char* useonetime = malloc(sizeof(char)*2);
  int first = 0;
  int x = 0;
  do
  {
    if(first == 0)
    {
      printf("Insert the number of char you want to consider\n");
    }
    else
    {
      printf("Invalid number %d, put a number from 1 to 18\n", x);
    }
    
    scanf("%s", useonetime);
    system("clear");
    x = atoi(useonetime);
    //printf("%d",x);
    first++;
  }while(x < 1 || x>18);

  //printf("\n%s", (row+262143)->array1);
  
  int eliminati = checkAdiancenti(*row, 0, x, 1, 0, eliminated, savefile, stamp);
  //printf("%d", contaS(0, *row));
  //stampa(*row);
  //stampaAll(row, 0);
  fprintf(log,"%d are elements eliminated by the filter 1\n", eliminati);
  printf("%d elements are eliminated\n", eliminati);
  //stampaAll(*row, 0);
  
  //adiacentiStampa(*row, 0);
  
  
}



int main(void) {
  string name;
  int first = 0;
  int nofile = 0;
  FILE* fileP; 
  char useonetime[255];
  char saved[255];
  char wordstampa[255];
  

  printf("·▄▄▄▄   ▐ ▄  ▄▄▄·     • ▌ ▄ ·.  ▄▄▄·  ▐ ▄  ▄▄▄·  ▄▄ • ▄▄▄ .▄▄▄  \n██▪ ██ •█▌▐█▐█ ▀█     ·██ ▐███▪▐█ ▀█ •█▌▐█▐█ ▀█ ▐█ ▀ ▪▀▄.▀·▀▄ █·\n▐█· ▐█▌▐█▐▐▌▄█▀▀█     ▐█ ▌▐▌▐█·▄█▀▀█ ▐█▐▐▌▄█▀▀█ ▄█ ▀█▄▐▀▀▪▄▐▀▀▄ \n██. ██ ██▐█▌▐█ ▪▐▌    ██ ██▌▐█▌▐█ ▪▐▌██▐█▌▐█ ▪▐▌▐█▄▪▐█▐█▄▄▌▐█•█▌\n▀▀▀▀▀• ▀▀ █▪ ▀  ▀     ▀▀  █▪▀▀▀ ▀  ▀ ▀▀ █▪ ▀  ▀ ·▀▀▀▀  ▀▀▀ .▀  ▀\n");
  printf("Press ENTER to get started...");
  getchar();
  system("clear");


do
{
  do
  {    
    if(nofile == 0)
    {
      if(first == 0)
      {
        //primo print
        printf("\n ____________________________\n|  ________________________  |\n| |                        | |\n| |                        | |\n| |   The file must have   | |\n| |  20 or LESS characters | |\n| |                        | |\n| |                        | |\n| |      WITHOUT THE       | |\n| |       EXTENSION        | |\n| |________________________| |\n|____________________________|\n\n");    
      }
      else
      {
        //dopo il primo print
        printf("\n ____________________________\n|  ________________________  |\n| |                        | |\n| |                        | |\n| |   THE FILE MUST HAVE   | |\n| |  20 OR LESS CHARACTERS | |\n| |          !!!!          | |\n| |                        | |\n| |      WITHOUT THE       | |\n| |       EXTENSION        | |\n| |________________________| |\n|____________________________|\n\n"); 
      }
    }
    else
    {
      printf("\n ____________________________\n|  ________________________  |\n| |                        | |\n| |                        | |\n| |   The file does not    | |\n| |        EXIST!!         | |\n| |                        | |\n| |                        | |\n| |      Reinsert the      | |\n| |      file's name       | |\n| |________________________| |\n|____________________________|\n\n"); 
      printf("Error file : %s\n", name.array1);
      
    }  
    printf("\nInsert the name of file : ");
    //Inserire il file
    scanf("%s", useonetime); //leggere file
    system("clear");
    first += 1; //togliere la prima volta
    
  }while(checkLunghezza(useonetime) > 20);

  name.array1 = (char*)malloc(sizeof(char)); 
  name.l = checkLunghezza(useonetime);
  
  //printf("%d\n" , name.l); //prova print lunghezza
  for(int i = 0; i < name.l; i++)
  {
   *(name.array1 + i) = useonetime[i];//copio il nome da useonetime creato per leggere la parola da scanf
  }
 attaccotxt(name.array1, name.l);
 //printf("%s ", name.array1);
 fileP = fopen(name.array1, "r");
 if(fileP == NULL)
 {
  nofile = 1; 
 }
}
while(fileP == NULL);



FILE * userActions = fopen("Log.txt","w");
FILE * eliminated = fopen("Eliminated Elemets.txt","w");
FILE * remain = fopen("Remaining.txt", "w");

fprintf(userActions, "\nSuccessfull Loading of the file %s...\n\n", name.array1);

int wordLenght = 20;
char word[wordLenght];

string* testo = (string*)malloc(sizeof(string)*262144);//il file letto e` qui

int i = 0;
int cont = 0; 
while(fgets(word, wordLenght, fileP)) 
{
  
  cont++;
  int j;
  (testo+i) -> array1 = (char*)malloc(sizeof(char)*20);
  for(j = 0; j < 18; j++ )
  {
    (testo+i) -> array1[j] = word[j];
  }
  //(testo+i) -> array1[18] = '\0';
  (testo+i+1) -> array1 = NULL;
  //(testo+i) -> array1 = word;
  
  //leggo il file e lo metto in un array
  //printf("\n%s",(testo+i) -> array1);per vedere se funzionava
  i++;
  //*(testo + i) = word; 
}
//i = 0;
fclose(fileP);

first = 0;
int x;
do
{
  do
  { 
    if(first != 0)
    {
      printf("The filter %d doesn't exist, please choose\none from the list below\n", x);
    }
    else
    {
      printf("The loading was succefull\n");
    }
    printf("\nThe total number of the all dna sequences is : %d\n",contaS(testo));
    printf("Which filter you want to apply?\n");
    printf("1. Adjacent Filter\n2. Palindrome Filter\n3. Mirror Filter\n4. Content A/G Filter\n5. Thanos's Filter\n\nGUI actions\n6. Print all remaining sequences (It may take a while)\n7. Save the remaining sequences to the file\n");
    scanf("%s", useonetime);
    system("clear");
    x = atoi(useonetime);
    first++;
  }while(x < 1 || x > 7);
int save = 0;
int stampanum = 0;
if(x < 6)
{
  do
  {
    
    printf(">> Would you like save the next operation's eliminated elements on file?\n (y/n)\n");
    scanf("%s",saved);
    switch(saved[0])
    {
      case 'y':
        save = 1;
        system("clear");
        printf("They will be saved...\n");
      break;
      case 'n':
        save = 0;
        system("clear");
      break;
      default:
        save = 2;
        system("clear");
        printf("Invalid command\n");
        
      break;
    }
  }while(save == 2);

  do
  {
    
    printf(">> Would you like print the eliminated elements on console?\n  (y/n)\n");
    scanf("%s", wordstampa);
    switch(wordstampa[0])
    {
      case 'y':
        stampanum = 1;
        system("clear");
        printf("They will be printed...\n");
      break;
      case 'n':
        stampanum = 0;
        system("clear");
      break;
      default:
        stampanum = 2;
        system("clear");
        printf("Invalid command\n");
        
      break;
    }
  }while(stampanum == 2);

}
  

  switch(x)
  {
    case 1:
      adiacentiM(&testo, userActions, eliminated, save, stampanum);
    break;
    case 2:
      palindromoM(&testo, userActions, eliminated, save, stampanum);
    break;
    case 3:
      mirrorM(testo, userActions, eliminated, save, stampanum);
      //joker = binary(testo+262142);
      //printf("\n%s,%s\n",(testo+joker)->array1,(testo+262142)->array1);
    break;
    case 4:
    contenutoAGM(testo, userActions, eliminated, save, stampanum); 
    break;
    case 5:
    thanosM(&testo, userActions, eliminated, save, stampanum);
    break;


    case 6:
    stampa(testo);
    break;
    case 7:
    riempi(testo, remain);
    printf("The save is successefull\n");
    break;


  }
  
  do
  {
    printf(">> Would you like do another operation?\n (y/n)\n");
    scanf("%s",useonetime);
    switch(useonetime[0])
    {
      case 'y':
        x = 1;
        first = 0;
        system("clear");
      break;
      case 'n':
        x = 0;
      break;
      default:
        x = 2;
        system("clear");
        printf("Invalid command\n");
        
      break;
    }
  }while(x == 2);

}while(x != 0);

system("clear");
printf("Thank you for using\nDevelopers:\n\tDeng Tian\n\tCecchin Tommy\n\tCiviero Riccardo\n\nGitHub :  https://github.com/Tian0w0/DNA-manager ");



return 0;
}